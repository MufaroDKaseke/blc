<?php

define('EMAIL', 'omorfotechlabs@gmail.com');
define('PASSWORD', 'towards2030');
?>
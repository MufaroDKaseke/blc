
## TODO

1. Create database
2. Design dashboard essentials
    - header
    - sidebar
    - notifications panel
    - dash panel



### Database

Tables

1. Events
    - ID
    - Name of event
    - Date
    - Description
    - Link 
    - Created Date
2. Books
    - ID
    - Book Id
    - Title
    - Author
    - Publication Year
    - Category
    - Upload Link
    - Upload Date
3. Videos
    - ID
    - code
    - title
    - description
    - caption
    - video link
    - upload date
4.  Users
    - ID
    - user_id
    - name
    - username
    - password
    - entry_date

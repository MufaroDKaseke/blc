

$('#toggleSidebar').on('click', function() {

$('#sidebar').toggleClass('show-sidebar');

});
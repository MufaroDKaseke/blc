<section class="notification-panel">
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="notification">
          <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong><span class="badge badge-pill badge-success"><i class="fa fa-check"></i></span></strong> You should check in on some of those fields below.
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>             
        </div>
      </div>
    </div>
  </div>
</section>
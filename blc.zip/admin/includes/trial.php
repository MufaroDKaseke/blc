<?php
$date = new DateTime('2021-07-08T19:38');
echo $date->format('m/d/Y H:i:s');
?>
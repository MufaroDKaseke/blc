<div id="sidebar" class="sidebar-wrapper">
  <div class="sidebar-heading">
    <h4>Dashboard</h4>
  </div>
  <ul class="sidebar-nav nav flex-column">
    <li class="nav-item active">
      <a href="<?php echo ROOT;?>/dashboard/" class="nav-link">Home</a>
    </li>
    <li class="nav-item">
      <a href="<?php echo ROOT;?>/dashboard/events.php" class="nav-link">Events</a>
    </li>
    <li class="nav-item">
      <a href="<?php echo ROOT;?>/dashboard/materials.php" class="nav-link">Materials</a>
    </li>
    <li class="nav-item">
      <a href="<?php echo ROOT;?>/dashboard/videos.php" class="nav-link">Videos</a>
    </li>
<!--<li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="libraryDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <span>Users</span><i class="fa fa-angle-right"></i>
      </a>
      <div class="dropdown-menu" aria-labelledby="libraryDropdown">
        <a class="dropdown-item" href="#">Books</a>
        <a class="dropdown-item" href="#">Another action</a>
      </div>
    </li>-->
  </ul>
</div>